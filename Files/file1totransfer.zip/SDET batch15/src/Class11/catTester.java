package Class11;

public class catTester {
    public static void main(String[] args) {
        //creating object fron the class
        cat cat1=new cat();

        cat1. name="lego";
        cat1 .breed="van cat";
        cat1.color="gray";
        cat1.attitude=false;
        cat1.eat();

        cat cat2=new cat();
        cat2.name="loki";
        cat2.breed="Domestic";
        cat2.color="white";

        System.out.println(cat2.breed);
        cat2.speak();






    }
    }



