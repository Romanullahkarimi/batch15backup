package Class12;

public class stringDemo4 {
    public static void main(String[] args) {
        String str="  ";
        boolean isEmpty=str.isEmpty();
        System.out.println(isEmpty);


    }
}
