package Class12;

public class stringDemo6 {
    public static void main(String[] args) {

        String str=" j a v a    y";
        // it removes the space from start and end not from in between
        System.out.println(str.trim());
    }
}
