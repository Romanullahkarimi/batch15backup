package Class12;

public class carTester {
    public static void main(String[] args) {
        //create the object of the class

        car BMW=new car();
        BMW.make="BMW";
        BMW.model="2022";
        BMW.color="white";
        BMW.moveforward();
        BMW.applyBreakes();
    }
}
