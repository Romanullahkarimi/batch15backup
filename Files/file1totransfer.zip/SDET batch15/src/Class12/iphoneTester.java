package Class12;

public class iphoneTester {
    public static void main(String[] args) {

    }
}
