package Class8;

public class NestedLoops {
    public static void main(String[] args) {


           for (int j=0;j<5;j++){//inner for loop
               System.out.println(j);
           }
        for (int j=0;j<5;j++){//inner for loop
            System.out.println(j);
        }  for (int j=0;j<5;j++){//inner for loop
            System.out.println(j);
        }
           System.out.println("**************");
       }

    }

