package class16;

public class personTester {
    public static void main(String[] args) {



   /*     person person = new person();
       // System.out.println(person.bankBalance);
        System.out.println(person.name);
        System.out.println(person.Address);*/
    }
}