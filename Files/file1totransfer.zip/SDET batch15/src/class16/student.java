package class16;

public class student {
    String name;
    String Id;
    String schoolName;
    int age;
    double weight;
    void printname(){
        System.out.println(name);
    }
    static void printStudentInfo(){
     //   System.out.println(name);
       // System.out.println(scho);
    }
}
