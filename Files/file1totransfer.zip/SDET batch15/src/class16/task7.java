package class16;

public class task7 {
    /*   Create a Class called Students
       Create three  variables  Name , ID  and  numberOfStudents
       Create three objects of the Students Class
       Set the value for  studentName , studentID and increment  the numberOfStudents for each object
       Print out  total number of students
   */
    String name;
    String ID;
   static   int NumberOfStudent;



    public static void main(String[] args) {
        task7 grade=new task7();

        grade.name="roman";
        grade.ID="1";
        grade.NumberOfStudent++;

        task7 grade1=new task7();

        grade1.name="roman";
        grade1.ID="2";
        grade1.NumberOfStudent++;
    }
}
