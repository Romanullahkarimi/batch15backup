package class13;

public class SplitMethodDemo {
    public static void main(String[] args) {
        String str = "i like java. i write a lot of code today. i am from batch 15";
    }
}
