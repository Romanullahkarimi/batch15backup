package class13;

public class StringDemo1 {
    public static void main(String[] args) {
        String str="romanullah";
        System.out.println(str);
        System.out.println(str.replace("Ro","RO"));
    }
}
