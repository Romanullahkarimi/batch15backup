package Class1;

public class Test_Git {
    public static  void main(String args[]){
        System.out.println("Hello Git Hub");
        System.out.println("first class");
    }
}
