package class29;

import java.util.ArrayList;

public class ArrayListDemo1 {
    public static void main(String[] args) {
      //  Dog d1=new Dog("jacky","persion",15);
        ArrayList<Dog>dogs=new ArrayList<>();
        dogs.add(new Dog("fulik","tiger",13));
    }
}
