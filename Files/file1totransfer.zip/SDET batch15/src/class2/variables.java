package class2;

public class variables {
    public static void main(String[]args) {
    short mybox=1000;
    System.out.println(mybox);
    byte box2=127;
    byte box3=-128;
    short Mybox=1000;
    int biggerbox=134424244;
    long maxbox=12223444444l;

        System.out.println(mybox);
    }
}
