package class2;

import java.sql.SQLOutput;

public class StringAddition {
    public static void main(String[] args) {

        String firstName="roman ";
        String lastName="karimi";

        System.out.println(firstName);
        System.out.println(lastName);

    }
}
