package class2;

public class VariablesCalculation {
    public static void main(String[] args) {
        double F1 = 10.5;
        double F2 = 10.5;

        double Addition = (F1+F2);
        double Subtraction = (F1-F2);
        double Multiplication = (F1*F2);
        double Division = (F1 /F2);

        System.out.println("the Addition of 2 number "+F1+" and " + F2 +" is equal to "+Addition);
        System.out.println("the Subtraction of 2 number " +F1+ " and " + F2 +" is equal to "+Subtraction);
        System.out.println("the Multiplication of 2 number " +F1+ " and " + F2+ " is equal to "+ Multiplication);
        System.out.println("the Division of 2 number " +F1+ " and " + F2+ " is equal to "+Division );

        double f1=3.9;
        double Square =(f1*f1);
        System.out.println(" the Square of " +3.9+ " is equal to  " +Square);


    }
}
