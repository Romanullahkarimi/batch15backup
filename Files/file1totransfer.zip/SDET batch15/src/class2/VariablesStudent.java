package class2;

public class VariablesStudent {
    public static void main(String[] args) {
        String Name=("romanullah");
        String Lastname=("karimi");
        byte Grade=8;
        String Job=("software engineer in test");
        String City=("Queens");
        String State=("New york");
        String Gendar=("M");
        boolean Honest=true;
        String PhoneNumber=("3472453194");

        System.out.println("Name:"+" "+Name);
        System.out.println("LastName:"+" "+Lastname);
        System.out.println("Grade:"+" "+Grade);
        System.out.println("job:"+ " "+Job);
        System.out.println("city:"+" "+City);
        System.out.println("State:"+" "+State);
        System.out.println("Gender:"+" "+Gendar);
        System.out.println("honest:"+" "+Honest);
        System.out.println("PhoneNumber:"+" "+PhoneNumber);

    }
}
