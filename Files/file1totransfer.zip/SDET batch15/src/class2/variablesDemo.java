package class2;

public class variablesDemo {
    public static void main(String[] args) {


        String name="romanullah";
        int age=26;
        String city= "khost";
        char Gender= 'm';
        String number="+2342-3434";
        boolean smart=true;

        System.out.println(name);
        System.out.println(age);
        System.out.println(city);
        System.out.println(Gender);
        System.out.println(number);
        System.out.println(smart);


    }
}
