package Class3;

public class IfEles_10 {
    public static void main(String[] args) {

        boolean hungry=true;
        if(hungry)
        {
            System.out.println("let's eat buddy ");
        }
    }
}
