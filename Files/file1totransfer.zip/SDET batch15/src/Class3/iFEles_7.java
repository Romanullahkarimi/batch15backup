package Class3;

public class iFEles_7 {
    public static void main(String[] args) {


        int money=150;
        System.out.println(money>=300);
        if (money>=300)

        {
            System.out.println("karimi lets go fo shopping");
        }

        if (money<300){
            System.out.println("lets save it");
            System.out.println("may be i spent to much money");
        }
    }
}
