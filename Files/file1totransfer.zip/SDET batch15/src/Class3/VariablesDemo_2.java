package Class3;

public class VariablesDemo_2 {
    public static void main(String[] args) {
        int age=10;
        System.out.println(age);
        age=20;
        System.out.println(age);
        age=age+20;
    }
    }

