package Class3;

public class RelationalOperation_6 {
    public static void main(String[] args) {
        /*
        atithmatic operatars
        int +int=int
        int/int=>int
        int-








        == equal to
        !=not equal to
        > greater than
        <less than
        >= greater or equal
        <= less or equal

         */

        int number=10;
        int number2=10;
        System.out.println(number+number2);
        boolean result=20>10;
        System.out.println(20>10);//is 20 greater than 10 => true
        System.out.println(5>10);// is 5 grater than 10 =>false
        System.out.println(5!=10);//is 5 not equal to 10 =>true
        System.out.println(5==10);//is 5 is  equal to 5 => false
        System.out.println(5==5);//is 5 is  equal to 5 => true
        System.out.println(5>=20);//is 10 is  greater or equal  to 20 => false
        System.out.println(10<=20);//is 10 is less or  equal to 20 => true
        System.out.println(20<=20);//is 20 is less or  equal to 20 => true




    }
}
