package Class3;

public class VariablesDemo1 {
    public static void main(String[] args) {
        int age=10;
        int salary=10;//only create a box of  type int and dont assign any value to it//
        salary=12000;
        System.out.println(salary);
        String name,city,country;//we can create multiple boxes in a single line of code//
        char gender,letter;
        name="Daria";//store a values in the variable//
        System.out.println(name);//i have not stored city anything that y jave is confused//


    }
}
