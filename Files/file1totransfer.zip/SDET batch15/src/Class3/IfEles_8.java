package Class3;

public class IfEles_8 {
    public static void main(String[] args) {

        int age=10;

        if(age<11)

        {
            System.out.println("time is good");
        }
        boolean inSyntaxbootcamp=true;

    }
}