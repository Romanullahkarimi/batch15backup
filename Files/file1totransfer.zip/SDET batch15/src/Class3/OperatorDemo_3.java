package Class3;

public class OperatorDemo_3 {
    public static void main(String[] args) {
        int number=10;
        System.out.println(number/3);//3
        System.out.println(number%3);//1
        System.out.println(155%2);//we can always the modulus is by if the answer is 0 its an even number other
        //its an add number

        System.out.println(1555%5);

    }
}
