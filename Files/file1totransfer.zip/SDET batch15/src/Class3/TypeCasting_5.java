package Class3;

public class TypeCasting_5 {
    public static void main(String[] args) {

        long number=125;
        byte shortNumber=(byte)number;
        float f=10.5f;
        int num=(int)f;
        System.out.println(shortNumber);
        System.out.println(num);
        /*
        byte
        short
        int
        long
        float
        double
        if we
         */
        byte b=10;
        int number2=b;
        System.out.println();

    }
}
