   package Class9;

public class ArraysDemo8 {
    public static void main(String[] args) {

        char[] letters={'I',' ','L','o','v','e',' ','J','a','v','a'};
        for (int i = 0; i < letters.length; i++) {
            System.out.print(letters[i]);

        }


    }}