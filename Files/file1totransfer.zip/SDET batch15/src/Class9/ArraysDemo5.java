package Class9;

public class ArraysDemo5 {
    public static void main(String[] args) {

        int  number =10;
        int [] numbers= new int[5];
        numbers[0]=50;
        numbers[1]=30;
        numbers[2]=44;
        numbers[4]=53;
        numbers[5]=45;

        for (int i = 0; i < numbers.length; i++) {
            System.out.println(numbers[i]);

        }



    }}