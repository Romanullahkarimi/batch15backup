package Class5;

public class logicalOperators {
    public static void main(String[] args) {


        System.out.println(!true);
        System.out.println(!false);
        boolean rich=true;
        System.out.println(!rich);
        int number=9;
        if(number==1){
            System.out.println("hello wold");
        }else {
            System.out.println("hello java");
        }
        String country="afghanistan";
        if(country.equals("bad cauntry")){
            System.out.println("you are wellcome");

        }if (country.equals("china"));{
            System.out.println("you are wellcome");

        }if(country.equals("india")){
            System.out.println("you are wellcome");
        }








    }
}
