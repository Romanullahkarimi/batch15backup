
package Class5;

import java.util.Scanner;

public class Task6 {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("please enter number value 1");
        int number1=scan.nextInt();
        System.out.println("Please enter number value 2");
        int number2=scan.nextInt();
        System.out.println("Please enter number value 3");
        int number3=scan.nextInt();

        if(number1>number2||number1>number3);
        System.out.println(number1+" is the largest number");
        if(number2>number1||number2>number3);
        System.out.println(number2+" is the largest number");
        if(number3>number1||number3>number2);
        System.out.println(number3+" is the largest number");

    }


    }


