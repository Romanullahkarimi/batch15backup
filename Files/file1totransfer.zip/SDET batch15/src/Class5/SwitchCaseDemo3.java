
package Class5;

public class SwitchCaseDemo3 {
    public static void main(String[] args) {

        int number=10;
        switch (number){

        }


    }}