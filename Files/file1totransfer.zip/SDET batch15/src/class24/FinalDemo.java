package class24;

public class FinalDemo {

}
