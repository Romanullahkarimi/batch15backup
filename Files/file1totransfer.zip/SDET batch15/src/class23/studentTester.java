package class23;

public class studentTester {
    public static void main(String[] args) {
        student students=new student();


    }
}
