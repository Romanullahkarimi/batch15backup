package class23;

public class finalKeyword {
   final double gravity=9.8;
 final    double pi=3.14;
    double lightSpeed=2334333;
    void tryChangingGravity(){
    //    gravity; 1,3//we get an erorrs
    }
}
