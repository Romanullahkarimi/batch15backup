package class19;

public class donkeyTester {
    public static void main(String[] args) {
      donkey donkey=  new donkey("paper",3);//defult contsructer created by compiler
                                //when a programmer does not create one
        donkey.print();
        //
    }
}
