package class19;

public class school {
    public static void main(String[] args) {
        Teacher teacher1=new Teacher("Roman",21,"java");
        Teacher teacher2=new Teacher("ahmad",22,"pashto");

    }
}
