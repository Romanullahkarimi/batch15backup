package Class6;

import java.util.Scanner;

public class logicalAndDemo {
    public static void main(String[] args) {


        System.out.println("will you pass exam");
        boolean understand=true;
        boolean enjoyjava=true;

        if(understand&&enjoyjava){
            System.out.println("you get the job qucikly");
        }else {
            System.out.println("we need to work hard");
        }



    }
    }

