package Class6;

public class whileLoop4 {
    public static void main(String[] args) {


        int number=1;
        int sum=0;
        while (sum<=5){
            sum=sum+number;
            number++;

        }
        System.out.println(sum);

    }


}

