package Class6;

import java.util.Scanner;

public class IncremetOperator {
    public static void main(String[] args) {
       int number =10;
       number=number+1;
        System.out.println(number);
        number+=1;
        System.out.println(number);
        number++;
        System.out.println(number);
        int number2=10;
        number2--;
        System.out.println(number2);


        }

    }


