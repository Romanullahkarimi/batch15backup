package class14;

public class MethodTester2 {
    public static void main(String[] args) {
        //creating an object of the class
      MethodsDemo2 md=new MethodsDemo2();
      //md.printHello();//calling method
       // md.printHelloManyTimes(12);
        md.printManyTimes(5,"i love Quraan");
    }


}
