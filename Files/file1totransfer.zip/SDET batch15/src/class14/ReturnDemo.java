package class14;

public class ReturnDemo {
    String method(){
        return "hello world";
    }
    int method2(){
        return 23;
    }

}
