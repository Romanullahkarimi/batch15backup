package class14;

import java.util.Scanner;

public class ReturnDemo2 {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        int num=scan.nextInt();
        System.out.println(num);
    }
}
