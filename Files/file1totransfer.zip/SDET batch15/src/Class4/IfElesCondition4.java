package Class4;

public class IfElesCondition4 {
    public static void main(String[] args) {
        int num1 = 10;
        int num2 = 10;
        /*
        if num1 is equal to num2 o console => numbers are equal
        if num1>num2 =>nm1 is greater than num2
        if num2 >num1 => num2 is greater than num1
         */
        if (num1 == num2) {
            System.out.println("nums are equal");
        } else if (num1 > num2) {
            System.out.println("nm1 is greater than num2");
        } else if (num2 > num1) {
            System.out.println("num2 is greater than num1");

        }


        {

        }

    }
}
