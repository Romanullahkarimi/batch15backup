package Class4;

public class IfDemo1 {

    public static void main(String[] args) {
        int money = 15000;


        if (money > 1000) {
            System.out.println("let's buy iphone");
        }
        if (money > 200) {
            System.out.println("let's also buy computer");
        }
        boolean motherday = true;

        if (motherday) {


            System.out.println("happy mother day");
        }
        String name = "Romanullah";
        if (name.equals("Romanullah")) {
            System.out.println("i love him");
        }
    }
}
