package Class4;

import java.util.Scanner;

public class homework {
    public static void main(String[] args) {
        boolean sunny=true;
        int weather=85;
        if(sunny){
            System.out.println("It is a sunny day, I should go somewhere!");
        }if(sunny ){
            System.out.println("I stay home and practice java");
        }if(weather>85){
            System.out.println("I am going to the beach");
        }else{
            System.out.println("I am going to the park");
        }
    }
}