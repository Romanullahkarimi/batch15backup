package Class4;

public class NestIfDemo5 {
    public static void main(String[] args) {

        int money=1000;
        String day="sunday";
        boolean mood=false;
        if (money>700){


        }if(mood){
            System.out.println("lets go to shopping");
        }if(day.equals("sunday")){
            System.out.println("sorry i am not feeling well");
        }
        else{
            System.out.println("save some money for future");
        }
        }
    }

