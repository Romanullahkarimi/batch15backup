package class27;

public class BoxingDemo {
    public static void main(String[] args) {
        int number=15;
        printData(number);
    }
    public static void printData(Integer number){
        System.out.println(number);
    }
}
