package class27;
import java.util.ArrayList;

public class demo4 {
    public static void main(String[] args) {
        /*
        int=> Integer
        byte=> Byte
        short=> Short;
        boolean=>Boolean
         */
        ArrayList<Integer>number=new ArrayList<>();
        number.add(15);
        number.add(20);
        number.add(46);
        number.add(150);
        number.add(56);
        System.out.println(number);

    }
}
