package Class7;

import java.util.Scanner;

public class DoWhileLoops {
    public static void main(String[] args) {

      Scanner scan=new Scanner(System.in);

        int number=0;
        do {
            System.out.println("please enter a number");
            number=scan.nextInt();
        }while (number!=5);


        int number1=0;
        while (number1!=0){

        }

    }

}
