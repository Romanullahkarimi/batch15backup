package class20;

public class sportTest {
    public static void main(String[] args) {
        cricket cric=new cricket("Rashid khan ","Afghanistan","green");
        cric.display();
    }
}
