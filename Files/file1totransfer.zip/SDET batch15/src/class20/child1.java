package class20;

public class   child1  {
    public static void main(String[] args) {
  /*  child1 cl=new child1();
    cl.hello();
    parent.bye();//accesing static method in a static way by using clas name
    child1.bye();//accessing satitc  methods
    cl.name="romanullah";
    child1.lastName="karimi";*/


}}
