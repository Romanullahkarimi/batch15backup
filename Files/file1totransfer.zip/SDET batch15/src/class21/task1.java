package class21;

public class task1 {
 /*   Create 1 class in which create a methods that will calculate the area of
            Rectangle
            Square*/
}
