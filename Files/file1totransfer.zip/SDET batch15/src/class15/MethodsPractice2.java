package class15;

public class MethodsPractice2 {
    public static void main(String[] args) {
        MethodPractice2 metho=new MethodPractice2();
        System.out.println(metho.reverseStr(" i love java"));
    }
}
