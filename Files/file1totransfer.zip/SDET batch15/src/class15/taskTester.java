package class15;

public class taskTester {
    public static void main(String[] args) {


        take num = new take();
        boolean iseven=num.isEven(100);
        System.out.println(iseven);
    }
}