package class15;

public class Mpractice3 {
    //create a method that takes an array of int sum all the number from the array
    //and return the sum
    int array(int []  arr) {

        int sum = 0;
        for (int num:arr) {


            sum += num;
        }
        return sum;
    }

}




