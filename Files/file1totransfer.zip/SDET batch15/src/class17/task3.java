package class17;

public class task3 {
}