package class17;

public class StudentTester {
    public static void main(String[] args) {
        student student=new student ("1","Romanulah",25,190);
        student.printInfo();
        student student1=new student ("2","Jan",20,180);
        student.printInfo();
        student student2=new student ("3","Afghan",18,160);
        student.printInfo();
        student studen3t=new student ("4","khan",23,170);
        student.printInfo();
        student student4=new student ("5","Khostwall",22,150);
        student.printInfo();



    }
}
