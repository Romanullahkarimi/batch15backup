package Class10;

public class ForEachLoopDemo1 {
    public static void main(String[] args) {

        String[] names={"Roman","hamdard,","karimi"};

        for (String name:names){
            System.out.println(name);

        }


    }
}