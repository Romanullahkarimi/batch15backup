package Class12;

public class StringDemo3 {
    public static void main(String[] args) {
        String firstname="Muhammad SW";
        String lastname=" is massenger of Allah";
        //easy and famus way of concatination

        System.out.println(firstname+" "+lastname);

        //another way of concatination
        System.out.println(firstname.concat(lastname));
    }
}
