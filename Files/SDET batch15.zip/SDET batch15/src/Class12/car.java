package Class12;

public class car {

    String make;
    String model;
    String color;
    int years;


    void moveforward(){
        System.out.println("car is moving forward");
    }
    void applyBreakes(){
        System.out.println("applying the brakes");
        System.out.println("car stopped");
    }

}
