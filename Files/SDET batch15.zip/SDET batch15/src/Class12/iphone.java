package Class12;

public class iphone {
  int year;
  String make;
  String newVersion;
  String color;
  void buyingNew (){
      System.out.println("it's expensive ");

  }
  void buyingOld(){
      System.out.println("its not expensive");
      System.out.println("sava money for it");
  }
}
