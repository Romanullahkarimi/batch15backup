package Class12;

public class StringDemo2 {
    public static void main(String[] args) {
        String str="JAVA IS FUN";
        String str1=str.toLowerCase();
        System.out.println(str1);

        String num="roman";
        String num1=num.toUpperCase();
        System.out.println(num1);
    }
}
