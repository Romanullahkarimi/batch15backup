package Class12;

public class stringDemo11 {

    public static void main(String[] args) {
        String str="send it to support channel";
        //we can also specfy the starting point and the ending point
        String strc=str.substring(5,12);
        System.out.println(strc);
    }
}
