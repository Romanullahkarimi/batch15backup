package class21;

public class calculatorTester {
    public static void main(String[] args) {
        calculator calculator=new calculator();
        calculator.add(10,10);

    }
}
