package class21;

public class animalTester {
    public static void main(String[] args) {
        Cat animal=new Cat();
        animal.printColor();
    }
}
