package class19;

public class store {
    public static void main(String[] args) {
     furniture furniture=new furniture("Table",120,"white");
     furniture.print();
    }
}
