package class19;

public class book {
  /*  Write a Student class   that have instance variables name and address.
    Create a constructor that will initialize those variables. Print name & address of given  student using displayInfo method.*/
    String author;
    String tiltle;
    int years;
    book(String author, String tiltle){
        this.author=author;
        this.tiltle=tiltle;

    }


}
