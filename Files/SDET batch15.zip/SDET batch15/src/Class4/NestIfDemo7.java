package Class4;

public class NestIfDemo7 {
    public static void main(String[] args) {

        boolean studyHard = true;
        int salary = 9000;
        if (studyHard) {
            System.out.println("we get the job");

            if (salary > 100000) {
                System.out.println("let's buy home");

            } else {
                System.out.println("calm dowm");

            }


        } else {
            System.out.println("it might take little longer for us to get the job");
        }


    }
}
