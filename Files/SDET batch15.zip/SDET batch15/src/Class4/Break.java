package Class4;

public class Break {
    public static void main(String[] args) {
        boolean FiFa_final=true;
        if(FiFa_final){
            System.out.println("let's watch it right now");
        }
        else{
            System.out.println("let's continue the class");
        }
    }
}
