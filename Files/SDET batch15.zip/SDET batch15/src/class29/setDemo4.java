package class29;

import java.util.TreeSet;

public class setDemo4 {
    public static void main(String[] args) {
        TreeSet<Integer> fruit=new TreeSet<>();
      fruit.add(1);
      fruit.add(1);
      fruit.add(20);
      fruit.add(5);
      fruit.add(3);
      fruit.add(4);
        System.out.println(fruit);
    }
}
