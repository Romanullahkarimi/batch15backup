package class29;

import java.util.ArrayList;
import  java.util.HashSet;
import java.util.List;

public class setsDemo1 {
    public static void main(String[] args) {

   /*     List<String>list=new ArrayList<>();
        list.add("java");
        list.add("java");
        list.add("java");
        list.add("java");
        System.out.println(list );*/
        HashSet<String>fruit=new HashSet<>();
        fruit.add("mango");
        fruit.add("mango");
        fruit.add("mango");
        fruit.add("mango");
        System.out.println(fruit);

    }
}
