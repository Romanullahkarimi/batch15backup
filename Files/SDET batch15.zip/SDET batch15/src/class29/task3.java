package class29;

import java.util.ArrayList;

public class task3 {
    public static void main(String[] args) {
     //   3)Create an arrayList of words. Remove every word that ends with “e”.
        ArrayList<String>makeup=new ArrayList<>();
        makeup.add("Lipstick");
        makeup.add("Eyeline");
        makeup.add("Blushone");
        makeup.add("Foundation");

    }
}
