package class17;

public class dogTester {
    public static void main(String[] args) {
        dog husky=new dog(" husky "," husky the dog ",2,25);
        husky.printInfo();
        dog bulldog=new dog("bulldog","bulldog the dog",3,130);
        bulldog.printInfo();
     /*   dog dog=new dog();
        dog.name="tiger";
        dog.breed="pitbul";
        dog.age=2;*/

        /*dog bulldog=new dog();
        bulldog.name="tiger";
        bulldog.breed="pitbul";
        bulldog.age=2;*/
    }
}
