package class17;

public class taskTester {
    public static void main(String[] args) {
        task2 task2=new task2();

        System.out.println( task2.reverseStr("monday"));
    }
}
