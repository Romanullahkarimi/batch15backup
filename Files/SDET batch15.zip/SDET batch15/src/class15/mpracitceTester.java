package class15;

public class mpracitceTester {
    public static void main(String[] args) {
        Mpractice3 sum=new Mpractice3();
        int[]arr={12,34,42,4};
        System.out.println(sum.array(arr));
        System.out.println(sum.array(new int[]{10,12}));

    }
}
