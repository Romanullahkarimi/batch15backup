package class15;

public class Methods {
    void  doSomeThing(){
        int sum=0;
        for (int i = 0; i < 10; i++) {
            sum=+i;
        }

    }
    String metod2(){
        return "java is hard";
    }
}
