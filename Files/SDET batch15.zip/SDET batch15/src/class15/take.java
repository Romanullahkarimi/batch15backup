package class15;

public class take {
    //call isEven method for the number 100 12 20
    boolean isEven(int number){
        if(number%2==0){
            return true;
        }else {
            return false;
        }
    }
    boolean isEven1(int numbe1){
        return numbe1%2==0;
    }
}
