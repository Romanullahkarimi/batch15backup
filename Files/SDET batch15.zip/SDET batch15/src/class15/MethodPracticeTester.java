package class15;

public class MethodPracticeTester {
    public static void main(String[] args) {
        MethodPractice num=new MethodPractice();
     boolean iseven=  num.method(13);
        System.out.println(iseven);
    }
}
