package Class7;

public class ForLoop4 {
    public static void main(String[] args) {
      for(int i =1;i<=10;i++){
          System.out.println(" 6 * "+i+" = "+(6*i));
      }


}

    }
