package Class9;

public class ArraysDemo3 {
    public static void main(String[] args) {


        char[]letters={'A','b','C','D','E','F'};

        for (int i = 0; i < letters.length; i++) {
            System.out.println(letters[i]);

        }




    }}