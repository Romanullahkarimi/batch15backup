package class2;

public class VariablesDemo2 {
    public static void main(String[] args) {

        int numberBox=20;
        numberBox=20;
        numberBox=30;
        numberBox=40;

        System.out.println(numberBox);
        System.out.println(numberBox+40);

    }
}
