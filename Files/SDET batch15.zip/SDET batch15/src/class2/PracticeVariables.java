package class2;

public class PracticeVariables {
    public static void main(String[] args) {

        byte box1=20;
        short box2=325;
        int box3=2334444;
        long box4= 208000884443l;
        float box5=18.1555f;
        double box6=88.8888;
        int box7='R';
        Boolean happy=true;
        System.out.println(box1);
        System.out.println(box2);
        System.out.println(box3);
        System.out.println(box4);
        System.out.println(box5);
        System.out.println(box6);
        System.out.println(happy);



    }
}
