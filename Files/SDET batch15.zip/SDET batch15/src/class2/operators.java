package class2;

public class operators {
    public static void main(String[] args) {
        String number1="10";
        String number2="20";



        int number3=10;
        int number4=20;

        System.out.println(number3+number4);
        System.out.println(number3-number4);
        System.out.println(number3*number4);
        System.out.println(number3/number4);

    }
}
