package class2;

public class VariablesValues {
    public static void main(String[] args) {
        byte number1=125;
        short number2=2222;
        long number3=2599999999l;
        int number4='$';
        float number5=45.111f;
        double number6=2333.55;
        boolean rich=true;

        number1=127;
        number2=1572;
        number3=127777777777777777l;
        number4='@';
        number5=13.555f;
        number6=127.55;
        boolean happy=true;
        System.out.println(number1);
        System.out.println(number2);
        System.out.println(number3);
        System.out.println(number4);
        System.out.println(number5);
        System.out.println(number6);


    }
}
