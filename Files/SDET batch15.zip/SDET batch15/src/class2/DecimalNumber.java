package class2;

public class DecimalNumber {
    public static void main(String[] args) {


        double myNumberBox=10.5f;
        double largeDecaimalBox=1233443.3432;
        System.out.println(myNumberBox);
        System.out.println(largeDecaimalBox);

      /*
        char latter = 's';
        char gender = 'M';
        char symbol = '#';
        char number = '1';

       */




    }
}
