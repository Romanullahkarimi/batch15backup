package class2;

public class VariablesMath {
    public static void main(String[] args) {

        double W = 5.0;
        double H = 8.0;
        double p = 2 * (W+H);
        double a = W*H;
        System.out.println("The perimeter of Rectangle with width "+W+ " and height " +H+ " is equal to "
                +p+  " and the area is equal to " +a);



    }
}
