package Class11;

import java.util.Scanner;

public class DogTester {
    public static void main(String[] args) {
        //we are creating actual object from the class scanner

        //this how we create  the object class
        Dog dog1=new Dog();
        dog1.bark();
        dog1.sleep();
        System.out.println(dog1.age);



    }
    }

