package Class11;

public class Example1 {
    public static void main(String[] args) {

        int[][] matrix = {{10, 20, 30},
                          {45, 55, 60},
                          {30, 40, 59, 60, 78},

        };
        //write a loop to print all the element from 2D array
        for (int i = 0; i < matrix.length; i++) {

            for (int j = 0; j < matrix[i].length; j++) {
                if (matrix[i][j] % 2 != 0) {
                    System.out.print(matrix[i][j] + " ");

                }}
                System.out.println();


            }

        }
    }
