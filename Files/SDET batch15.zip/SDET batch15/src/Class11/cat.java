package Class11;

public class cat {
//attributes/field/properties

    String name;

    String color;

    String breed;
    int age;
    boolean attitude;
    void speak(){
        System.out.println("Meow Meow");
    }
    void eat(){
        System.out.println("eating fish");
    }
}


