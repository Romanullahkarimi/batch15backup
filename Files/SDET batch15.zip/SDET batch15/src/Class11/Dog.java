package Class11;

public class Dog {
//attributes/field/properties
        String name;

        String breed;

        int age;
        double wight;

        String color;
        //behaviour/methods/functions
        void bark(){
            System.out.println("woof woof");
        }
        void sleep(){
            System.out.println("ZZZZZZZZZZZ");
        }
        void eat(){
            System.out.println("Dog is eating.......");
        }
    }

