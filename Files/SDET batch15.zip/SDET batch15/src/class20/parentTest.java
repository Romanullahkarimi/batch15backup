package class20;

public class parentTest {
   // new parent  cannot create an object of the parent class since the constructor
}
