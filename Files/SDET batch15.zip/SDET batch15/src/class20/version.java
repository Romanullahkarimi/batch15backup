package class20;

public class version {
    public static void main(String[] args) {

    userClass scan=new userClass("roman",12344556) ;


    }}

