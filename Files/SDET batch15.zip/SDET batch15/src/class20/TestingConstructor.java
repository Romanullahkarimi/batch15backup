package class20;

public class TestingConstructor {
    public static void main(String[] args) {
        subclass sub=new subclass();

    }

}
