package class20;

public class TestingSuperKeyWork {
    public static void main(String[] args) {
        Child child=new Child();
        child.callMe();
    }
}
