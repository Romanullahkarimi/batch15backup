package class14;

public class ReturnDemoTester {
    public static void main(String[] args) {

        ReturnDemo rd=new ReturnDemo();

        String str= rd.method();
        System.out.println(str);
        int result= rd.method2();
        System.out.println(result);
    }

}
