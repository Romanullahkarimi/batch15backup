package class14;

public class Math {
    //write the methods that takes 2 int numbers add and show the results on console

    void add(int num1,int num2){
        System.out.println(num1+num2);
    }
    //create a method that takes 3 int number and multiply them show
    // the results on console
    void m(int num1,int num2,int num3){
        System.out.println(num1*num2*num3);
    }
    int sub(int num1,int num2){
        return (num1-num2);
    }
}
