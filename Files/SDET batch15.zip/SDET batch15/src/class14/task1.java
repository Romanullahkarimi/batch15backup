package class14;

public class task1 {
    public static void main(String[] args) {
       // 1) Create a String that will hold a sentence. Write a program to get a new String
       // without any spaces.
        String str="batch 15 is great";
        String strnew=str.replaceAll(" "," ");
        System.out.println(strnew);
    }
}
