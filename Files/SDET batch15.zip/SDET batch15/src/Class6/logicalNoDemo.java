package Class6;

public class logicalNoDemo {
    public static void main(String[] args) {

        String password="abcdef";
        if(!password.equals("abcdef")){
            System.out.println("password");
        }else {
            System.out.println("wrong password");
        }

        boolean israining=true;
        if(!israining){
            System.out.println("lets go for a walk");
        }else
        {
            System.out.println("stay home and sleep");
        }
    }
}
