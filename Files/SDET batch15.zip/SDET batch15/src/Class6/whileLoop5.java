package Class6;

public class whileLoop5 {
    public static void main(String[] args) {


        int number=1;
        boolean flaq=true;

        while (flaq)
            System.out.println(number);
            if (number>3);{
                flaq=false;

        }number++;

    }


}

