package Class6;

public class whileLoop1 {
    public static void main(String[] args) {


      /*  int number=0;
        if(number<3){
            System.out.println("hello world");

            number++;
            if(number<3){
                System.out.println("hello world");
            }
            number++;
            if(number<3){
                System.out.println("hello world");
         */
            int number2=0;
            while (number2<10){//keep on checking the condition untill it return to true
                System.out.println("hello world");
                number2++;//intcrement the number2 by one
            }



        }


        }




