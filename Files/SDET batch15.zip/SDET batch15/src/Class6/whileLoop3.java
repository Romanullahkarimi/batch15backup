
package Class6;

public class whileLoop3 {
    public static void main(String[] args) {

        int number =1;
        while (number<=5)
        {
            System.out.println(number);
            number++;

        }
        System.out.println("****************");
        int number2=0;
        while (number2<5){
            System.out.println(number2);
            number2+=2;
        }

    }}