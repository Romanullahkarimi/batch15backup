package class22;

public class EmployeeTester {
    public static void main(String[] args) {
        manager manager=new manager();
        manager.printSalary();
        officeBoys officeBoys=new officeBoys();
        officeBoys.printSalary();

    }
}
