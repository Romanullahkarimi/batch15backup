package class27;

import java.util.ArrayList;

public class Demo3 {
    public static void main(String[] args) {
        // we hava created an array of string
        ArrayList<String> names=new ArrayList();
        ////ass methods tp add element tp this arraylist
        // they are diamond operator or angle brakcets we specify the data type in them
        names.add("nelson");
        names.add("sam");
        names.add("Diana");
        names.add("Zahara");
        names.add("saba");
        System.out.println(names);
    }
}
