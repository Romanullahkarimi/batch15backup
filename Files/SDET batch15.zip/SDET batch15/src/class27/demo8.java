package class27;

import java.util.ArrayList;

public class demo8 {
    public static void main(String[] args) {
        ArrayList<String> names=new ArrayList<>();
        names.add("fizzy");
        names.add("roman");
        names.add("tarik");
        names.add("urwa");
        names.add("abeera");
        names.add("savo");
        System.out.println(names);
        names.clear();
        System.out.println(names);
    }
}
