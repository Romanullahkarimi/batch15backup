package Class8;

public class RecapDemo2 {
    public static void main(String[] args) {

        for (int A=10;A>=10;A-=2);
    }}