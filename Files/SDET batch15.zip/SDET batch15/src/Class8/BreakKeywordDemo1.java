package Class8;

public class BreakKeywordDemo1 {
    public static void main(String[] args) {
        boolean summer = true;
        int temp = 75;
        while (summer) {
            if (temp <= 100) {
                System.out.println("i love weather because temp" + temp);
            } else {

                System.out.println("it's very hot" + temp);
                break;
            }

                temp +=5;





        }


        boolean sum=true;

    }}