package Class8;

import java.util.Scanner;

public class Repalit63 {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("please enter number");
        int x=scan.nextInt();

        for (int i=0;i<x;i++){
            System.out.println(i+" ");
        }
}
}