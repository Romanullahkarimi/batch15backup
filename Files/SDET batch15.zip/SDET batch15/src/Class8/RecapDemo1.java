package Class8;

public class RecapDemo1 {
    public static void main(String[] args) {
         int namber=10;
         while (namber>=2);
        System.out.println(namber);
        namber-=2;

        System.out.println("******************");
        int num=10;
        do {
            System.out.println(num);
        }
            while (num >= 2) ;


        num-=2;

}
}