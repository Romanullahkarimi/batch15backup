package Class10;

public class ArrayDemo {
    public static void main(String[] args) {

    }
}
