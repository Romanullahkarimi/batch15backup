package class13;

public class task2 {
    public static void main(String[] args) {
      //  2) Create a String and print it in reverse order (Sunday → yadnuS).
        String str="sunday";
        for (int i =str.length()-1 ;i>=0; i--) {
            System.out.println(str.charAt(i));

        }
    }
}
