package class13;

public class BuilderDemo {
    public static void main(String[] args) {
       /* StringBuilder stringBuilder= new StringBuilder("sunday");
        System.out.println(stringBuilder.reverse());*/
        String state="va";
        String state1="va";
        String state3="va";
        String state4="va";
        String state5="va";
        String state6="va";
        String state7="va";
        //once we enter value to string then we can't change it bc its unchangeble
         state7="usa";


    }
}
