package Class3;

public class ShortHandOperator_4 {
    public static void main(String[] args) {
        int number=10;

        //number=number+10;
        number=number*10;//whatever is stored in number variable add 10 to it.
        System.out.println(number);
        int number2=20;
        number2-=10;
        System.out.println(number2);

        int number3=100;
        number3/=10;
        System.out.println(number3);

        double number1=10.5;
       // double number2=10.5;
        double Addition=number1+number2;
        System.out.println("the addition of number 2 "+number1+ " and "+number2+"is equal to"+Addition);


    }
}