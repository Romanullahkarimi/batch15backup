package Class3;

public class IFEles_9 {

    public static void main(String[] args) {

        char c='m';

        if(c=='m')

        {
            System.out.println("Male");
        }
        String name="Roman";
        // we cant use not permitive data type == symbol
        if(name.equals("Roman"))
        {
            System.out.println("amazing student");
        }
        if(!name.equals("karimi"))
        {
            System.out.println("best player");
        }
    }
}
