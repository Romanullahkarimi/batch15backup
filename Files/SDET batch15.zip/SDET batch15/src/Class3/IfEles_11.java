package Class3;

public class IfEles_11 {

    public static void main(String[] args) {

        int money=1500;
        if(money>300)
        {
            System.out.println("let's go for shopping");
        }


    }
}
