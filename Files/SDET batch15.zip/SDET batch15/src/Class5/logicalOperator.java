package Class5;

public class logicalOperator {
    public static void main(String[] args) {


        if(10>5||4>6){
            System.out.println("1");
        }else {
            System.out.println("2");
        }

        String name="Muhammad sw";
        int age =63;
        if(name.equals("Muhammad sw")&& age==63){
            System.out.println(" Muhammad sw the  last and fist propet of Allah ");
        }else {
            System.out.println("i don't know you");
        }

        boolean istrue= false;
        System.out.println(!istrue);
        if(!istrue){
            System.out.println("you got it ");
        }else {
            System.out.println("need more practice");
        }
    }
}
