package Class5;

public class SwitchCaseDemo {
    public static void main(String[] args) {


    }
}
